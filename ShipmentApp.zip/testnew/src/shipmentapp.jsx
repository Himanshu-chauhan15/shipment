/* ShipmentApp.jsx - Plain React + Tailwind Setup */

import React, { useState, createContext, useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';

// Authentication context
const AuthContext = createContext();
const useAuth = () => useContext(AuthContext);

// Fake auth functions
const authAPI = {
  login: (username) => Promise.resolve({ username }),
  register: (username) => Promise.resolve({ username }),
};

// Guarded Route component
const Protected = ({ children }) => {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" replace />;
};

// Login / Register Form
function AuthForm({ mode }) {
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const { setUser } = useAuth();
  const nav = useNavigate();

  const submit = async () => {
    if (!username.trim()) return setError('Required');
    try {
      const u = await (mode === 'login' ? authAPI.login(username) : authAPI.register(username));
      setUser(u);
      nav('/dashboard');
    } catch {
      setError('Failed');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-20 p-6 bg-white rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4 capitalize">{mode}</h2>
      <input
        className="w-full mb-2 p-2 border rounded"
        placeholder="Username"
        value={username}
        onChange={(e) => { setError(''); setUsername(e.target.value); }}
      />
      {error && <div className="text-red-500 mb-2">{error}</div>}
      <button
        onClick={submit}
        className="w-full py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        {mode === 'login' ? 'Login' : 'Register'}
      </button>
      <div className="mt-4 text-center">
        {mode === 'login' ? (
          <button onClick={() => nav('/register')} className="text-blue-600 hover:underline">
            Create account
          </button>
        ) : (
          <button onClick={() => nav('/login')} className="text-blue-600 hover:underline">
            Have account?
          </button>
        )}
      </div>
    </div>
  );
}

// Main Dashboard
function Dashboard() {
  const { user, logout } = useAuth();
  const [shipments, setShipments] = useState([]);
  const [form, setForm] = useState({ sender: '', receiver: '', size: '', address: '' });
  const [trackId, setTrackId] = useState('');
  const [status, setStatus] = useState('');

  const create = () => {
    const id = `SHIP-${Date.now()}`;
    setShipments([...shipments, { id, status: 'Processing', ...form }]);
    setForm({ sender: '', receiver: '', size: '', address: '' });
  };

  const track = () => {
    const found = shipments.find(s => s.id === trackId.trim());
    setStatus(found ? found.status : 'Not Found');
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Hi, {user.username}</h1>
        <button onClick={logout} className="text-red-600 hover:underline">Logout</button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* New Shipment Form */}
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-lg font-semibold mb-4">New Shipment</h2>
          {['sender','receiver','size','address'].map(f => (
            <input
              key={f}
              className="w-full mb-2 p-2 border rounded"
              placeholder={f.charAt(0).toUpperCase() + f.slice(1)}
              value={form[f]}
              onChange={e => setForm({ ...form, [f]: e.target.value })}
            />
          ))}
          <button onClick={create} className="mt-2 w-full py-2 bg-green-600 text-white rounded hover:bg-green-700">
            Create
          </button>
        </div>

        {/* Track Shipment Form */}
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-lg font-semibold mb-4">Track Shipment</h2>
          <input
            className="w-full mb-2 p-2 border rounded"
            placeholder="Tracking ID"
            value={trackId}
            onChange={e => setTrackId(e.target.value)}
          />
          <button onClick={track} className="w-full py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Track
          </button>
          {status && <div className="mt-3 font-semibold">Status: {status}</div>}
        </div>
      </div>

      {/* Shipments List */}
      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">My Shipments</h2>
        {shipments.length === 0 ? (
          <div className="text-gray-500">No shipments yet.</div>
        ) : (
          shipments.map(s => (
            <div key={s.id} className="bg-white p-4 mb-3 rounded shadow">
              <div><strong>ID:</strong> {s.id}</div>
              <div><strong>Status:</strong> {s.status}</div>
              <div><strong>From:</strong> {s.sender}</div>
              <div><strong>To:</strong> {s.receiver}</div>
              <div><strong>Address:</strong> {s.address}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// App Root
export default function ShipmentApp() {
  const [user, setUser] = useState(null);
  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, setUser, logout }}>
      <Router>
        <Routes>
          <Route path="/login" element={<AuthForm mode="login" />} />
          <Route path="/register" element={<AuthForm mode="register" />} />
          <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
          <Route path="/*" element={<Navigate to={user ? '/dashboard' : '/login'} />} />
        </Routes>
      </Router>
    </AuthContext.Provider>
  );
}
